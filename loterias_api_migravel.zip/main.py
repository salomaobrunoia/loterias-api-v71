from flask import Flask, jsonify
import requests

app = Flask(__name__)

BASE_URL = "https://loteriascaixa-api.herokuapp.com/api"

@app.route("/")
def root():
    return jsonify({"status": "API migrada ativa"})

@app.route("/api/<modalidade>/latest")
def resultado_mais_recente(modalidade):
    try:
        url = f"{BASE_URL}/{modalidade}/latest"
        r = requests.get(url)
        return jsonify(r.json())
    except Exception as e:
        return jsonify({"erro": str(e)}), 500